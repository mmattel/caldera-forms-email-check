<?php
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

echo Caldera_Forms_Processor_UI::config_fields( cf_email_check_validator_fields() );
