<?php
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

echo Caldera_Forms_Processor_UI::config_fields( EDCCF_email_domain_fields_for_validator() );
